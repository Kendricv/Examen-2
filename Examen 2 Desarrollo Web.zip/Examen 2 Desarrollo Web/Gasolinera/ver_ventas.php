<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gasolinera_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}


$sql = "SELECT tipo_gasolina, galones, total, apoyo_social_aplicado FROM ventas_gasolina";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Ventas</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="form-container">
        <h2>Registro de Ventas</h2>

        <table>
            <tr>
                <th>Tipo de Gasolina</th>
                <th>Galones</th>
                <th>Total (Q)</th>
                <th>Apoyo Social Aplicado</th>
            </tr>

            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['tipo_gasolina'] . "</td>";
                    echo "<td>" . $row['galones'] . "</td>";
                    echo "<td>Q" . $row['total'] . "</td>";

                    
                    if ($row['apoyo_social_aplicado'] == 1) {
                        echo "<td>Sí (Q5 aplicados)</td>";
                    } else {
                        echo "<td>No</td>";
                    }

                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No hay ventas registradas.</td></tr>";
            }

            $conn->close();
            ?>

        </table>
    </div>
</body>
</html>
