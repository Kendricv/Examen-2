<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "postes_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$no_poste = isset($_GET['no_poste']) ? $_GET['no_poste'] : '';

if ($no_poste) {
    $sql = "SELECT * FROM postes WHERE no_poste = '$no_poste'";
} else {
    $sql = "SELECT * FROM postes";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Postes</title>
    <link rel="stylesheet" href="estilos2.css">
</head>
<body>
    <div class="form-container">
        <h2>Buscar Poste</h2>
        <form action="ver_postes.php" method="GET">
            <label for="no_poste">No. de Poste:</label>
            <input type="text" id="no_poste" name="no_poste">
            <input type="submit" value="Buscar">
        </form>
        
        <button onclick="window.location.href='index.html'">Regresar al Menú Principal</button>

        <h2>Registros de Postes</h2>
        <table>
            <thead>
                <tr>
                    <th>No. de Poste</th>
                    <th>Fecha de Registro</th>
                    <th>Dirección</th>
                    <th>Departamento</th>
                    <th>Municipio</th>
                    <th>Referencia</th>
                    <th>Longitud</th>
                    <th>Latitud</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['no_poste']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['fecha_registro']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['direccion']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['departamento']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['municipio']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['referencia']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['longitud']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['latitud']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No se encontraron registros</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php

$conn->close();
?>