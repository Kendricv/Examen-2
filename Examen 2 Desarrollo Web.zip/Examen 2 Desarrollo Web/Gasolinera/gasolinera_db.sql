-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-09-2024 a las 22:46:46
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `gasolinera_db`
--
CREATE DATABASE IF NOT EXISTS `gasolinera_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `gasolinera_db`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `precios_gasolina`
--

CREATE TABLE `precios_gasolina` (
  `id` int(11) NOT NULL,
  `tipo_gasolina` varchar(50) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `apoyo_social` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `precios_gasolina`
--

INSERT INTO `precios_gasolina` (`id`, `tipo_gasolina`, `precio`, `apoyo_social`) VALUES
(2, 'Super', 37.50, 5.00),
(3, 'Regular', 30.50, 5.00),
(4, 'Diesel', 28.50, 5.00),
(5, 'Super', 32.50, 5.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas_gasolina`
--

CREATE TABLE `ventas_gasolina` (
  `id` int(11) NOT NULL,
  `tipo_gasolina` varchar(50) NOT NULL,
  `galones` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `apoyo_social_aplicado` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas_gasolina`
--

INSERT INTO `ventas_gasolina` (`id`, `tipo_gasolina`, `galones`, `total`, `apoyo_social_aplicado`) VALUES
(1, 'Super', 101.00, 3787.50, 0),
(2, 'Super', 10.00, 375.00, 0),
(3, 'Super', 100.00, 3750.00, 0),
(4, 'Super', 100.00, 3750.00, 0),
(5, 'Diesel', 400.00, 11400.00, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `precios_gasolina`
--
ALTER TABLE `precios_gasolina`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ventas_gasolina`
--
ALTER TABLE `ventas_gasolina`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `precios_gasolina`
--
ALTER TABLE `precios_gasolina`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `ventas_gasolina`
--
ALTER TABLE `ventas_gasolina`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
