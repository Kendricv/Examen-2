<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "postes_db";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$no_poste = $_POST['no_poste'];
$fecha_registro = $_POST['fecha_registro'];
$direccion = $_POST['direccion'];
$departamento = $_POST['departamento'];
$municipio = $_POST['municipio'];
$referencia = $_POST['referencia'];
$longitud = $_POST['longitud'];
$latitud = $_POST['latitud'];


$sql = "INSERT INTO postes (no_poste, fecha_registro, direccion, departamento, municipio, referencia, longitud, latitud) 
        VALUES ('$no_poste', '$fecha_registro', '$direccion', '$departamento', '$municipio', '$referencia', '$longitud', '$latitud')";

if ($conn->query($sql) === TRUE) {
    echo "Nuevo poste registrado correctamente";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>
