<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tipo_gasolina = $_POST['tipo_gasolina'];
    $precio = $_POST['precio'];
    
   
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "gasolinera_db";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }
    
    $sql = "INSERT INTO precios_gasolina (tipo_gasolina, precio) VALUES ('$tipo_gasolina', '$precio')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Precio registrado exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Precios de Gasolina</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="form-container">
        <h2>Registrar Precios de Gasolina</h2>
        <form action="registrar_precios.php" method="POST">
            <label for="tipo_gasolina">Tipo de Gasolina:</label>
            <select id="tipo_gasolina" name="tipo_gasolina" required>
                <option value="Super">Super</option>
                <option value="Diesel">Diesel</option>
                <option value="Regular">Regular</option>
            </select>
            <label for="precio">Precio (Q):</label>
            <input type="text" id="precio" name="precio" required>
            <input type="submit" value="Registrar">
        </form>
    </div>
</body>
</html>