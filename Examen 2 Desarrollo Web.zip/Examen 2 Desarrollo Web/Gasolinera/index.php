<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Principal</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="menu-container">
        <h2>Gestión de Gasolinera</h2>
        <ul class="menu">
            <li><a href="registrar_precios.php">Registrar Precios</a></li>
            <li><a href="venta_gasolina.php">Venta de Gasolina</a></li>
            <li><a href="ver_ventas.php">Ver Ventas</a></li>
        </ul>
    </div>
</body>
</html>