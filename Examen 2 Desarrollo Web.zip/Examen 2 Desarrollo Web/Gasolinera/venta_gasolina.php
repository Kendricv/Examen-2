<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tipo_gasolina = $_POST['tipo_gasolina'];
    $galones = $_POST['galones'];

    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "gasolinera_db";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    
    $sql = "SELECT precio, apoyo_social FROM precios_gasolina WHERE tipo_gasolina = '$tipo_gasolina'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $precio = $row['precio'];
    $apoyo_social = $row['apoyo_social'];

    
    $total = $precio * $galones;
    $apoyo_social_aplicado = 0;

    
    if ($total < 100) {
        $total -= $apoyo_social;  
        $apoyo_social_aplicado = 1; 
    }

    
    $sql = "INSERT INTO ventas_gasolina (tipo_gasolina, galones, total, apoyo_social_aplicado) 
            VALUES ('$tipo_gasolina', '$galones', '$total', '$apoyo_social_aplicado')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Venta registrada exitosamente. Total: Q" . $total;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Venta de Gasolina</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="form-container">
        <h2>Venta de Gasolina</h2>
        <form action="venta_gasolina.php" method="POST">
            <label for="tipo_gasolina">Tipo de Gasolina:</label>
            <select id="tipo_gasolina" name="tipo_gasolina" required>
                <option value="Super">Super</option>
                <option value="Diesel">Diesel</option>
                <option value="Regular">Regular</option>
            </select>
            <label for="galones">Galones:</label>
            <input type="text" id="galones" name="galones" required>
            <input type="submit" value="Calcular y Registrar Venta">
        </form>
    </div>
</body>
</html>
